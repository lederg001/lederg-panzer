"""Small local SQLite history database."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path


class ScanStore:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target TEXT NOT NULL,
                started_at TEXT NOT NULL,
                finished_at TEXT,
                findings_count INTEGER NOT NULL,
                result_json TEXT NOT NULL
            )""")

    def _connect(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def save(self, result: dict) -> int:
        with self._connect() as conn:
            cursor = conn.execute(
                "INSERT INTO scans(target, started_at, finished_at, findings_count, result_json) VALUES(?,?,?,?,?)",
                (result.get("target", ""), result.get("started_at", ""), result.get("finished_at"), len(result.get("findings", [])), json.dumps(result, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def recent(self, limit: int = 100) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute("SELECT id,target,started_at,finished_at,findings_count FROM scans ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(row) for row in rows]

    def get(self, scan_id: int) -> dict | None:
        with self._connect() as conn:
            row = conn.execute("SELECT result_json FROM scans WHERE id=?", (scan_id,)).fetchone()
            return json.loads(row["result_json"]) if row else None
