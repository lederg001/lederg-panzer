"""Target normalization and guardrails for authorized single-host assessments."""
from __future__ import annotations

import ipaddress
import re


class ScopeError(ValueError):
    """Raised when a target is outside the supported single-host scope model."""


_LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")


def normalize_target(value: str) -> str:
    """Normalize a single hostname or IP address; reject URLs, ranges and lists."""
    raw = (value or "").strip()
    if not raw:
        raise ScopeError("Укажите домен или IP-адрес.")
    if any(ch in raw for ch in "/\\?@*%, \t\r\n"):
        raise ScopeError("Разрешён только один домен или IP — без URL, путей, масок и списков.")

    # IP literals are parsed before rejecting colons (IPv6 uses colons).
    try:
        return ipaddress.ip_address(raw.strip("[]")).compressed
    except ValueError:
        pass

    if ":" in raw or raw.startswith(".") or raw.endswith("."):
        if raw.endswith("."):
            raw = raw[:-1]
        else:
            raise ScopeError("Порт в target не указывается. Введите только домен или IP.")

    try:
        ascii_host = raw.encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise ScopeError("Некорректное имя домена.") from exc

    if len(ascii_host) > 253 or "." not in ascii_host:
        raise ScopeError("Введите полное доменное имя (например, example.com) или IP.")
    labels = ascii_host.split(".")
    if any(not _LABEL.fullmatch(label) for label in labels):
        raise ScopeError("Некорректное имя домена.")
    if labels[-1].isdigit():
        raise ScopeError("Последняя часть домена не должна состоять только из цифр.")
    return ascii_host
