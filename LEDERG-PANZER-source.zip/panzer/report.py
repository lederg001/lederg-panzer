"""HTML/JSON report rendering."""
from __future__ import annotations

import html
import json
from pathlib import Path

SEVERITY_COLORS = {"CRITICAL": "#ff3030", "HIGH": "#ff5b52", "MEDIUM": "#ffad42", "LOW": "#e6ce55", "INFO": "#7f9bad"}


def render_html(result: dict) -> str:
    target = html.escape(str(result.get("target", "unknown")))
    rows = []
    for finding in result.get("findings", []):
        severity = str(finding.get("severity", "INFO")).upper()
        color = SEVERITY_COLORS.get(severity, SEVERITY_COLORS["INFO"])
        rows.append(
            "<tr>"
            f"<td><b style='color:{color}'>{html.escape(severity)}</b></td>"
            f"<td>{html.escape(str(finding.get('title', '')))}<small>{html.escape(str(finding.get('category', '')))}</small></td>"
            f"<td>{html.escape(str(finding.get('details', '')))}</td>"
            f"<td>{html.escape(str(finding.get('recommendation', '')))}</td>"
            "</tr>"
        )
    if not rows:
        rows.append("<tr><td colspan='4'>Замечаний не обнаружено в выполненных проверках.</td></tr>")
    summary = {level: sum(1 for item in result.get("findings", []) if item.get("severity") == level) for level in SEVERITY_COLORS}
    summary_html = "".join(f"<div class='metric'><strong>{count}</strong><span>{level}</span></div>" for level, count in summary.items())
    modules_json = html.escape(json.dumps(result.get("modules", {}), ensure_ascii=False, indent=2))
    generated = html.escape(str(result.get("finished_at", "")))
    return f"""<!doctype html><html lang='ru'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>LEDERG PANZER — {target}</title><style>
:root{{color-scheme:dark}}body{{margin:0;background:#090b0e;color:#e9edf1;font:14px Segoe UI,Arial,sans-serif}}main{{max-width:1200px;margin:32px auto;padding:0 20px}}header{{border-left:4px solid #e3242b;padding:12px 18px;background:#14181e}}h1{{margin:0;color:#ff4048;letter-spacing:2px}}.muted{{color:#92a0ad}}.metrics{{display:flex;gap:10px;flex-wrap:wrap;margin:20px 0}}.metric{{background:#151a20;padding:14px 20px;border-radius:8px;min-width:75px}}.metric strong{{display:block;font-size:25px}}.metric span{{color:#9aa8b5;font-size:11px}}table{{width:100%;border-collapse:collapse;background:#11161c}}th,td{{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #28313a}}th{{color:#ff686d}}small{{display:block;color:#81909e;margin-top:5px}}pre{{background:#11161c;white-space:pre-wrap;overflow-wrap:anywhere;padding:16px;border-radius:8px}}footer{{margin:30px 0;color:#7d8994;font-size:12px}}</style>
<main><header><h1>LEDERG PANZER</h1><div class='muted'>AUTHORIZED SECURITY ASSESSMENT · Отчёт по цели: <b>{target}</b></div></header>
<p class='muted'>Завершено: {generated} · IP: {html.escape(str(result.get('resolved_ip','не определён')))}</p>
<div class='metrics'>{summary_html}</div><h2>Результаты и рекомендации</h2><table><thead><tr><th>Уровень</th><th>Наблюдение</th><th>Доказательства</th><th>Что исправить</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<h2>Технические данные</h2><pre>{modules_json}</pre><footer>LEDERG PANZER {html.escape(str(result.get('version','')))} · Проверяйте только собственные системы или цели с явным разрешением. Выводы автоматических проверок требуют ручной валидации.</footer></main></html>"""


def save_html(result: dict, path: Path) -> None:
    path.write_text(render_html(result), encoding="utf-8")


def save_json(result: dict, path: Path) -> None:
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
