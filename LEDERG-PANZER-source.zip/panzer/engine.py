"""Non-exploitative checks for one explicitly authorized host at a time."""
from __future__ import annotations

import concurrent.futures
import datetime as dt
import ipaddress
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable

import dns.exception
import dns.resolver

from .scope import normalize_target

VERSION = "0.1.0"
USER_AGENT = f"LEDERG-PANZER/{VERSION} (+authorized-security-audit)"

# A deliberately bounded set of common TCP ports. No arbitrary ranges/CIDRs.
COMMON_PORTS = (
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 465, 587,
    993, 995, 1433, 1521, 2049, 2375, 3000, 3306, 3389, 5432, 5601, 5900,
    6379, 8000, 8080, 8443, 8888, 9000, 9090, 9200, 9300, 11211, 27017,
)
SERVICE_NAMES = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP",
    110: "POP3", 111: "RPCbind", 135: "MSRPC", 139: "NetBIOS", 143: "IMAP",
    443: "HTTPS", 445: "SMB", 465: "SMTPS", 587: "SMTP submission", 993: "IMAPS",
    995: "POP3S", 1433: "MS SQL", 1521: "Oracle DB", 2049: "NFS", 2375: "Docker API",
    3000: "Dev web", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5601: "Kibana",
    5900: "VNC", 6379: "Redis", 8000: "Web app", 8080: "HTTP alternate", 8443: "HTTPS alternate",
    8888: "Web app", 9000: "Web app", 9090: "Admin web", 9200: "Elasticsearch",
    9300: "Elasticsearch transport", 11211: "Memcached", 27017: "MongoDB",
}


def _finding(severity: str, title: str, details: str, recommendation: str, category: str) -> dict:
    return {
        "severity": severity,
        "title": title,
        "details": details,
        "recommendation": recommendation,
        "category": category,
    }


def resolve_one(target: str) -> str:
    """Resolve the explicitly supplied hostname to one address, never a range."""
    normalized = normalize_target(target)
    try:
        return str(ipaddress.ip_address(normalized))
    except ValueError:
        pass
    try:
        records = socket.getaddrinfo(normalized, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise RuntimeError(f"DNS не смог разрешить цель {normalized}: {exc}") from exc
    if not records:
        raise RuntimeError(f"Для {normalized} не найден IP-адрес.")
    # One resolved address keeps the scanner bounded to a single host per run.
    return str(ipaddress.ip_address(records[0][4][0]))


def dns_audit(target: str) -> dict:
    host = normalize_target(target)
    records: dict[str, list[str]] = {}
    findings: list[dict] = []
    try:
        ip_obj = ipaddress.ip_address(host)
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2.0
        resolver.lifetime = 3.5
        try:
            ptr = resolver.resolve(ip_obj.reverse_pointer, "PTR", raise_on_no_answer=False)
            records["PTR"] = [r.to_text() for r in ptr] if ptr.rrset else []
        except Exception:
            records["PTR"] = []
        return {"records": records, "findings": findings}
    except ValueError:
        pass
    resolver = dns.resolver.Resolver()
    resolver.timeout = 2.0
    resolver.lifetime = 3.5
    for record_type in ("A", "AAAA", "MX", "NS", "TXT", "CAA"):
        try:
            answer = resolver.resolve(host, record_type, raise_on_no_answer=False)
            records[record_type] = [r.to_text() for r in answer] if answer.rrset else []
        except (dns.resolver.NXDOMAIN, dns.resolver.NoNameservers, dns.exception.Timeout, dns.resolver.NoAnswer):
            records[record_type] = []
        except Exception as exc:  # DNS providers can return uncommon response codes.
            records[record_type] = [f"Ошибка запроса: {type(exc).__name__}"]

    txt_values = " ".join(records.get("TXT", [])).lower()
    if "v=spf1" not in txt_values:
        findings.append(_finding(
            "MEDIUM", "SPF-запись не обнаружена",
            "В TXT-записях корневого домена не найдена политика SPF.",
            "Настройте SPF для всех легитимных отправителей почты и завершите политику подходящим механизмом.",
            "DNS / Email",
        ))
    try:
        dmarc = resolver.resolve(f"_dmarc.{host}", "TXT", raise_on_no_answer=False)
        dmarc_values = [r.to_text() for r in dmarc] if dmarc.rrset else []
    except Exception:
        dmarc_values = []
    records["DMARC"] = dmarc_values
    if not any("v=dmarc1" in value.lower() for value in dmarc_values):
        findings.append(_finding(
            "MEDIUM", "DMARC-запись не обнаружена",
            "Не найдена TXT-политика _dmarc для домена.",
            "Добавьте DMARC и сначала используйте режим мониторинга (p=none), затем ужесточайте политику после анализа отчётов.",
            "DNS / Email",
        ))
    if not records.get("CAA"):
        findings.append(_finding(
            "INFO", "CAA-записи отсутствуют",
            "DNS не возвращает CAA-записи, ограничивающие центры сертификации.",
            "Рассмотрите CAA, чтобы явно перечислить разрешённые центры сертификации.",
            "DNS / TLS",
        ))
    return {"records": records, "findings": findings}


class _SameHostRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, allowed_host: str):
        super().__init__()
        self.allowed_host = allowed_host.lower().rstrip(".")

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        new_host = (parsed.hostname or "").lower().rstrip(".")
        if parsed.scheme not in ("http", "https") or new_host != self.allowed_host:
            raise urllib.error.URLError("Redirect خارج نطاق الهدف المصرّح به / off-scope redirect blocked")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def tls_audit(host: str) -> dict:
    findings: list[dict] = []
    context = ssl.create_default_context()
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    try:
        with socket.create_connection((host, 443), timeout=5) as raw_sock:
            with context.wrap_socket(raw_sock, server_hostname=host) as tls_sock:
                cert = tls_sock.getpeercert()
                version = tls_sock.version() or "неизвестно"
                not_after = cert.get("notAfter")
                expires = dt.datetime.fromtimestamp(ssl.cert_time_to_seconds(not_after), tz=dt.timezone.utc) if not_after else None
                days_left = (expires - dt.datetime.now(dt.timezone.utc)).days if expires else None
                issuer = ", ".join("=".join(item) for group in cert.get("issuer", ()) for item in group)
                if days_left is not None and days_left < 0:
                    findings.append(_finding("HIGH", "TLS-сертификат просрочен", f"Сертификат истёк {expires:%Y-%m-%d %H:%M UTC}.", "Перевыпустите и установите действующий сертификат.", "TLS"))
                elif days_left is not None and days_left < 21:
                    findings.append(_finding("MEDIUM", "Срок TLS-сертификата скоро истекает", f"До окончания срока осталось примерно {days_left} дн.", "Продлите сертификат и проверьте автоматическое обновление.", "TLS"))
                return {"available": True, "version": version, "issuer": issuer, "expires": expires.isoformat() if expires else None, "days_left": days_left, "findings": findings}
    except (OSError, ssl.SSLError, ssl.CertificateError) as exc:
        findings.append(_finding(
            "MEDIUM", "Не удалось подтвердить корректный TLS на 443/tcp",
            f"TLS-подключение не прошло проверку сертификата или соединения: {type(exc).__name__}: {exc}",
            "Проверьте наличие HTTPS, цепочку сертификатов, имя узла и конфигурацию TLS. Это наблюдение требует ручного подтверждения.",
            "TLS",
        ))
        return {"available": False, "error": f"{type(exc).__name__}: {exc}", "findings": findings}


def web_audit(target: str) -> dict:
    host = normalize_target(target)
    findings: list[dict] = []
    opener = urllib.request.build_opener(_SameHostRedirectHandler(host))
    opener.addheaders = [("User-Agent", USER_AGENT), ("Accept", "text/html,application/xhtml+xml,*/*;q=0.5")]
    response_data = None
    requested_url = None
    errors = []
    url_host = f"[{host}]" if ":" in host else host
    for scheme in ("https", "http"):
        url = f"{scheme}://{url_host}/"
        request = urllib.request.Request(url, method="GET")
        try:
            with opener.open(request, timeout=8) as response:
                response_data = {
                    "status": response.status,
                    "url": response.geturl(),
                    "headers": response.headers,
                    "body_sample": response.read(131072),
                }
                requested_url = url
                break
        except urllib.error.HTTPError as exc:
            response_data = {"status": exc.code, "url": exc.geturl(), "headers": exc.headers, "body_sample": b""}
            requested_url = url
            break
        except Exception as exc:
            errors.append(f"{scheme}: {type(exc).__name__}: {exc}")
    if response_data is None:
        findings.append(_finding("INFO", "HTTP(S)-проверка недоступна", "; ".join(errors), "Проверьте доступность веб-сервера и правила сетевого доступа.", "HTTP"))
        return {"reachable": False, "errors": errors, "findings": findings}

    headers = response_data["headers"]
    header_map = {k.lower(): str(v) for k, v in headers.items()}
    final_scheme = urllib.parse.urlsplit(response_data["url"]).scheme
    if final_scheme != "https":
        findings.append(_finding("HIGH", "Главная страница доступна без HTTPS", f"Ответ получен по адресу {response_data['url']}.", "Включите HTTPS и постоянное перенаправление HTTP → HTTPS; защитите cookies атрибутом Secure.", "HTTP / TLS"))
    else:
        if "strict-transport-security" not in header_map:
            findings.append(_finding("MEDIUM", "Отсутствует HSTS", "Для HTTPS-ответа не найден заголовок Strict-Transport-Security.", "После проверки всех поддоменов настройте HSTS с корректным max-age; preload включайте осознанно.", "HTTP headers"))
    if "content-security-policy" not in header_map:
        findings.append(_finding("LOW", "Отсутствует Content-Security-Policy", "В ответе главной страницы не найден CSP.", "Настройте CSP в режиме report-only, устраните нарушения и затем включите политику.", "HTTP headers"))
    if "x-content-type-options" not in header_map:
        findings.append(_finding("LOW", "Отсутствует X-Content-Type-Options", "Браузеру не задано nosniff.", "Добавьте X-Content-Type-Options: nosniff.", "HTTP headers"))
    if "x-frame-options" not in header_map and "frame-ancestors" not in header_map.get("content-security-policy", "").lower():
        findings.append(_finding("LOW", "Не обнаружена защита от встраивания во фрейм", "Нет X-Frame-Options и CSP frame-ancestors.", "Установите CSP frame-ancestors; X-Frame-Options можно добавить для совместимости.", "HTTP headers"))
    if "referrer-policy" not in header_map:
        findings.append(_finding("INFO", "Не задан Referrer-Policy", "Политика передачи Referer явно не указана.", "Рассмотрите strict-origin-when-cross-origin или более строгую политику по требованиям приложения.", "HTTP headers"))
    if header_map.get("access-control-allow-origin", "").strip() == "*":
        findings.append(_finding("MEDIUM", "CORS разрешает любой origin", "Получен Access-Control-Allow-Origin: *.", "Ограничьте CORS доверенными origin. Дополнительно проверьте, что ответы не содержат персональные или секретные данные.", "CORS"))
    server = header_map.get("server")
    if server:
        findings.append(_finding("INFO", "Сервер раскрывает заголовок Server", f"Значение: {server[:160]}", "По возможности удалите точную версию ПО из публичного заголовка Server.", "Information disclosure"))
    cookies = headers.get_all("Set-Cookie", []) if hasattr(headers, "get_all") else []
    for cookie in cookies:
        cookie_name = cookie.split("=", 1)[0][:80]
        lower_cookie = cookie.lower()
        missing = [flag for flag, present in (("Secure", "secure" in lower_cookie), ("HttpOnly", "httponly" in lower_cookie), ("SameSite", "samesite=" in lower_cookie)) if not present]
        if missing:
            findings.append(_finding("LOW", f"Cookie {cookie_name}: отсутствуют атрибуты", f"Не найдены: {', '.join(missing)}.", "Для сессионных cookies установите Secure, HttpOnly и подходящий SameSite; проверьте назначение каждой cookie.", "Cookies"))
    return {
        "reachable": True,
        "requested_url": requested_url,
        "final_url": response_data["url"],
        "status": response_data["status"],
        "headers": header_map,
        "server": server,
        "cookies_checked": len(cookies),
        "findings": findings,
    }


def _check_port(ip_text: str, port: int, timeout: float) -> dict | None:
    ip_obj = ipaddress.ip_address(ip_text)
    family = socket.AF_INET6 if ip_obj.version == 6 else socket.AF_INET
    address = (ip_text, port, 0, 0) if family == socket.AF_INET6 else (ip_text, port)
    try:
        with socket.socket(family, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            result = sock.connect_ex(address)
            if result == 0:
                return {"port": port, "state": "open", "service": SERVICE_NAMES.get(port, "unknown")}
    except OSError:
        return None
    return None


def port_audit(target: str, timeout: float = 0.7) -> dict:
    host = normalize_target(target)
    ip_text = resolve_one(host)
    opened: list[dict] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
        futures = [pool.submit(_check_port, ip_text, port, timeout) for port in COMMON_PORTS]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                opened.append(result)
    opened.sort(key=lambda item: item["port"])
    findings: list[dict] = []
    high_risk = {23: "Telnet передаёт данные без современного шифрования", 2375: "Docker API часто предоставляет контроль над контейнерным хостом", 6379: "Redis не должен быть доступен недоверенным сетям", 9200: "Elasticsearch API может раскрывать данные", 27017: "MongoDB не должна быть открыта недоверенным сетям", 11211: "Memcached не должен быть доступен из публичной сети"}
    for entry in opened:
        port = entry["port"]
        if port in high_risk:
            findings.append(_finding("HIGH", f"Открыт потенциально чувствительный порт {port}", f"{entry['service']} ({high_risk[port]}). Сам факт открытого порта не доказывает уязвимость.", "Ограничьте доступ firewall/VPN, включите аутентификацию и проверьте сетевую экспозицию сервиса.", "TCP ports"))
        elif port in (21, 23, 445, 3389, 5900):
            findings.append(_finding("MEDIUM", f"Открыт административный/legacy-порт {port}", f"Обнаружен {entry['service']}.", "Разрешите доступ только из доверенных сетей, используйте шифрование и MFA там, где поддерживается.", "TCP ports"))
    return {"ip": ip_text, "checked_ports": len(COMMON_PORTS), "opened": opened, "findings": findings}


def run_assessment(target: str, modules: list[str], progress: Callable[[str], None] | None = None) -> dict:
    host = normalize_target(target)
    emit = progress or (lambda _message: None)
    result: dict = {
        "product": "LEDERG PANZER",
        "version": VERSION,
        "target": host,
        "started_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "modules": {},
        "findings": [],
    }
    result["resolved_ip"] = resolve_one(host)
    tasks = {
        "dns": ("DNS и почтовые записи", dns_audit),
        "web": ("HTTP-заголовки и cookies", web_audit),
        "tls": ("TLS-сертификат", tls_audit),
        "ports": ("Ограниченная проверка TCP-портов", port_audit),
    }
    for module in modules:
        if module not in tasks:
            continue
        label, function = tasks[module]
        emit(f"Выполняется: {label}…")
        try:
            data = function(host)
        except Exception as exc:
            data = {"error": f"{type(exc).__name__}: {exc}", "findings": [_finding("INFO", f"Модуль {module} завершился с ошибкой", str(exc), "Проверьте доступность цели и повторите проверку в разрешённой среде.", module)]}
        result["modules"][module] = data
        result["findings"].extend(data.get("findings", []))
    result["finished_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
    emit("Проверка завершена.")
    return result
