from __future__ import annotations

import json
import os
import queue
import sys
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from panzer import __version__
from panzer.engine import run_assessment
from panzer.report import save_html, save_json
from panzer.scope import ScopeError, normalize_target
from panzer.storage import ScanStore

APP_NAME = "LEDERG PANZER"
BG = "#090b0e"
PANEL = "#141920"
PANEL2 = "#1b222b"
RED = "#e32630"
TEXT = "#e8edf2"
MUTED = "#96a2ad"


def app_data_dir() -> Path:
    root = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    path = root / "LEDERG_PANZER"
    path.mkdir(parents=True, exist_ok=True)
    return path


class PanzerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"{APP_NAME} — v{__version__}")
        self.root.geometry("1240x840")
        self.root.minsize(980, 680)
        self.root.configure(bg=BG)
        self.data_dir = app_data_dir()
        self.store = ScanStore(self.data_dir / "panzer_history.db")
        self.events: queue.Queue = queue.Queue()
        self.scan_thread: threading.Thread | None = None
        self.current_result: dict | None = None
        self._configure_style()
        self._build_ui()
        self._refresh_history()
        self.root.after(150, self._poll_events)

    def _configure_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("Segoe UI Semibold", 20, "bold"))
        style.configure("Brand.TLabel", background=BG, foreground=RED, font=("Segoe UI Black", 25, "bold"))
        style.configure("PanelTitle.TLabel", background=PANEL, foreground=TEXT, font=("Segoe UI Semibold", 11, "bold"))
        style.configure("TButton", font=("Segoe UI Semibold", 10), padding=(12, 8), background=PANEL2, foreground=TEXT, borderwidth=0)
        style.map("TButton", background=[("active", "#2a333e"), ("disabled", "#20252b")])
        style.configure("Accent.TButton", background=RED, foreground="#ffffff", font=("Segoe UI Semibold", 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#ff424b"), ("disabled", "#623035")])
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(18, 10), font=("Segoe UI Semibold", 10))
        style.map("TNotebook.Tab", background=[("selected", PANEL2)], foreground=[("selected", "#ffffff")])
        style.configure("Treeview", background="#10151b", foreground=TEXT, fieldbackground="#10151b", rowheight=30, borderwidth=0)
        style.configure("Treeview.Heading", background=PANEL2, foreground="#ff7379", font=("Segoe UI Semibold", 9), relief="flat")
        style.map("Treeview", background=[("selected", "#4a2026")])
        style.configure("TCheckbutton", background=PANEL, foreground=TEXT, font=("Segoe UI", 9))
        style.map("TCheckbutton", background=[("active", PANEL)], foreground=[("active", "#ffffff")])
        style.configure("TEntry", fieldbackground="#0c1116", foreground=TEXT, insertcolor=TEXT, borderwidth=1, padding=8)
        style.configure("Horizontal.TProgressbar", background=RED, troughcolor=PANEL2, bordercolor=PANEL2, lightcolor=RED, darkcolor=RED)

    def _build_ui(self):
        header = tk.Frame(self.root, bg=BG, height=82)
        header.pack(fill="x", padx=24, pady=(16, 8))
        header.pack_propagate(False)
        left = tk.Frame(header, bg=BG)
        left.pack(side="left", fill="y")
        ttk.Label(left, text="LEDERG PANZER", style="Brand.TLabel").pack(anchor="w")
        ttk.Label(left, text="AUTHORIZED SECURITY ASSESSMENT TOOLKIT  ·  FREE / OPEN SOURCE", style="Muted.TLabel").pack(anchor="w")
        right = tk.Frame(header, bg=BG)
        right.pack(side="right", fill="y")
        tk.Label(right, text=f"VERSION {__version__}", fg=RED, bg=BG, font=("Consolas", 10, "bold")).pack(anchor="e", pady=(12, 2))
        tk.Label(right, text="LOCAL MODE  /  NO ACCOUNT REQUIRED", fg=MUTED, bg=BG, font=("Consolas", 8)).pack(anchor="e")
        tk.Frame(self.root, bg=RED, height=2).pack(fill="x", padx=24, pady=(0, 12))

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=24, pady=(0, 8))
        self.scan_tab = tk.Frame(self.notebook, bg=BG)
        self.history_tab = tk.Frame(self.notebook, bg=BG)
        self.knowledge_tab = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.scan_tab, text="  SCANNER  ")
        self.notebook.add(self.history_tab, text="  ИСТОРИЯ  ")
        self.notebook.add(self.knowledge_tab, text="  БАЗА ЗНАНИЙ  ")
        self._build_scan_tab()
        self._build_history_tab()
        self._build_knowledge_tab()

        self.status_var = tk.StringVar(value="Готово. Добавьте разрешённую цель для начала работы.")
        status = tk.Frame(self.root, bg="#11161c", height=32)
        status.pack(fill="x", side="bottom")
        status.pack_propagate(False)
        tk.Label(status, textvariable=self.status_var, bg="#11161c", fg=MUTED, anchor="w", font=("Segoe UI", 9)).pack(fill="both", padx=24)

    def _panel(self, parent, title: str):
        frame = tk.Frame(parent, bg=PANEL, padx=16, pady=14)
        ttk.Label(frame, text=title, style="PanelTitle.TLabel").pack(anchor="w", pady=(0, 10))
        return frame

    def _build_scan_tab(self):
        top = tk.Frame(self.scan_tab, bg=BG)
        top.pack(fill="x", pady=(8, 12))
        target_panel = self._panel(top, "01 / ЦЕЛЬ И ОБЛАСТЬ ТЕСТИРОВАНИЯ")
        target_panel.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.target_var = tk.StringVar()
        entry_row = tk.Frame(target_panel, bg=PANEL)
        entry_row.pack(fill="x")
        self.target_entry = ttk.Entry(entry_row, textvariable=self.target_var, font=("Consolas", 12))
        self.target_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.target_entry.insert(0, "example.com")
        ttk.Button(entry_row, text="ПРОВЕРИТЬ", style="Accent.TButton", command=self.start_scan).pack(side="right")
        self.consent_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            target_panel,
            text="Я владелец этой системы или имею явное разрешение на её проверку.",
            variable=self.consent_var,
        ).pack(anchor="w", pady=(11, 0))
        ttk.Label(target_panel, text="Поддерживается один домен или один IP. CIDR, маски, списки и массовое сканирование отключены.", style="Muted.TLabel").pack(anchor="w", pady=(7, 0))

        modules_panel = self._panel(top, "02 / МОДУЛИ")
        modules_panel.pack(side="right", fill="y", padx=(8, 0))
        self.module_vars = {
            "dns": tk.BooleanVar(value=True),
            "web": tk.BooleanVar(value=True),
            "tls": tk.BooleanVar(value=True),
            "ports": tk.BooleanVar(value=True),
        }
        labels = [("dns", "DNS / MX / SPF / DMARC"), ("web", "HTTP / Security Headers"), ("tls", "TLS / Certificate"), ("ports", "TCP / Common Ports")]
        for key, label in labels:
            ttk.Checkbutton(modules_panel, text=label, variable=self.module_vars[key]).pack(anchor="w", pady=2)

        info = tk.Frame(self.scan_tab, bg=BG)
        info.pack(fill="x", pady=(0, 12))
        self._stat_card(info, "38", "ПРОВЕРЯЕМЫХ TCP-ПОРТОВ", "Connect check · один IP", 0)
        self._stat_card(info, "6", "DNS ТИПОВ ЗАПИСЕЙ", "A / AAAA / MX / NS / TXT / CAA", 1)
        self._stat_card(info, "PASSIVE", "ВЕБ-ПРОВЕРКИ", "Без payload / brute force / exploit", 2)
        self._stat_card(info, "LOCAL", "ХРАНЕНИЕ", "SQLite · без облака", 3)

        result_panel = self._panel(self.scan_tab, "03 / РЕЗУЛЬТАТЫ ПРОВЕРКИ")
        result_panel.pack(fill="both", expand=True)
        toolbar = tk.Frame(result_panel, bg=PANEL)
        toolbar.pack(fill="x", pady=(0, 9))
        ttk.Button(toolbar, text="ЭКСПОРТ HTML", command=self.export_html).pack(side="left", padx=(0, 7))
        ttk.Button(toolbar, text="ЭКСПОРТ JSON", command=self.export_json).pack(side="left", padx=7)
        self.progress = ttk.Progressbar(toolbar, mode="indeterminate", length=150)
        self.progress.pack(side="right", padx=(8, 0))
        self.results_tree = ttk.Treeview(result_panel, columns=("severity", "category", "title"), show="headings", selectmode="browse")
        self.results_tree.heading("severity", text="УРОВЕНЬ")
        self.results_tree.heading("category", text="МОДУЛЬ")
        self.results_tree.heading("title", text="НАБЛЮДЕНИЕ")
        self.results_tree.column("severity", width=105, minwidth=90, stretch=False)
        self.results_tree.column("category", width=160, minwidth=130, stretch=False)
        self.results_tree.column("title", width=650, minwidth=250, stretch=True)
        self.results_tree.pack(fill="both", expand=True)
        self.results_tree.bind("<<TreeviewSelect>>", self._show_finding_details)
        self.detail_text = tk.Text(result_panel, height=5, bg="#0b1015", fg=TEXT, insertbackground=TEXT, relief="flat", wrap="word", font=("Segoe UI", 9), padx=10, pady=8)
        self.detail_text.pack(fill="x", pady=(9, 0))
        self.detail_text.insert("1.0", "Выберите наблюдение, чтобы увидеть доказательства и рекомендацию по исправлению.")
        self.detail_text.configure(state="disabled")
        self.finding_lookup: dict[str, dict] = {}

    def _stat_card(self, parent, number, title, caption, index):
        card = tk.Frame(parent, bg=PANEL, padx=14, pady=11)
        card.pack(side="left", fill="both", expand=True, padx=(0 if index == 0 else 6, 6 if index < 3 else 0))
        tk.Label(card, text=number, fg=RED, bg=PANEL, font=("Consolas", 15, "bold")).pack(anchor="w")
        tk.Label(card, text=title, fg=TEXT, bg=PANEL, font=("Segoe UI Semibold", 8, "bold")).pack(anchor="w", pady=(2, 0))
        tk.Label(card, text=caption, fg=MUTED, bg=PANEL, font=("Segoe UI", 8)).pack(anchor="w")

    def _build_history_tab(self):
        panel = self._panel(self.history_tab, "ЛОКАЛЬНАЯ ИСТОРИЯ СКАНИРОВАНИЙ")
        panel.pack(fill="both", expand=True, pady=8)
        ttk.Button(panel, text="ОБНОВИТЬ", command=self._refresh_history).pack(anchor="e", pady=(0, 10))
        self.history_tree = ttk.Treeview(panel, columns=("id", "target", "date", "count"), show="headings")
        for key, title, width in (("id", "ID", 65), ("target", "ЦЕЛЬ", 280), ("date", "ДАТА UTC", 260), ("count", "НАБЛЮДЕНИЯ", 140)):
            self.history_tree.heading(key, text=title)
            self.history_tree.column(key, width=width, stretch=(key == "target"))
        self.history_tree.pack(fill="both", expand=True)
        self.history_tree.bind("<Double-1>", self._open_history_item)
        ttk.Label(panel, text="Данные хранятся только на этом компьютере: panzer_history.db", style="Muted.TLabel").pack(anchor="w", pady=(9, 0))

    def _build_knowledge_tab(self):
        panel = self._panel(self.knowledge_tab, "PANZER FIELD GUIDE / СПРАВОЧНИК")
        panel.pack(fill="both", expand=True, pady=8)
        text = tk.Text(panel, bg="#0b1015", fg=TEXT, relief="flat", wrap="word", font=("Segoe UI", 10), padx=18, pady=16)
        text.pack(fill="both", expand=True)
        articles = [
            ("SCOPE / ОБЛАСТЬ РАЗРЕШЕНИЯ", "Проверяйте только активы, которыми владеете, или активы, на тестирование которых у вас есть явное разрешение. В рамках одной операции PANZER принимает только один домен или IP. Перед тестированием production-систем согласуйте окно работ и контакт для остановки."),
            ("OPEN TCP PORT", "Открытый порт — это сетевой сервис, который принимает TCP-соединения. Сам по себе открытый порт не доказывает наличие уязвимости. Проверьте, нужен ли сервис, ограничен ли доступ firewall/VPN, настроены ли аутентификация и обновления."),
            ("SPF / DKIM / DMARC", "SPF описывает, какие источники могут отправлять почту от имени домена. DKIM подписывает сообщения. DMARC задаёт обработку писем, не прошедших проверки SPF/DKIM, и позволяет получать отчёты."),
            ("SECURITY HEADERS", "CSP ограничивает источники контента; HSTS помогает браузеру использовать HTTPS; X-Content-Type-Options предотвращает MIME sniffing; frame-ancestors управляет встраиванием сайта во фреймы. Политики нужно адаптировать к приложению."),
            ("TLS CERTIFICATE", "Проверяйте срок действия, имя узла и доверенную цепочку. Предупреждение автоматического сканера не является полным криптографическим аудитом всех cipher suites."),
            ("FALSE POSITIVES", "Отсутствие заголовка или открытый порт — индикатор для проверки, а не доказательство эксплуатируемой уязвимости. Вручную подтвердите контекст, влияние и путь исправления перед публикацией отчёта."),
            ("NEXT STEPS", "Для расширенных проверок используйте OWASP Web Security Testing Guide, OWASP ZAP в passive/baseline-режиме и Nmap для утверждённой сетевой инвентаризации. Активные тесты и любые проверки с нагрузкой выполняйте только по согласованной программе."),
        ]
        for title, body in articles:
            text.insert("end", title + "\n", "heading")
            text.insert("end", body + "\n\n")
        text.tag_configure("heading", foreground="#ff5c64", font=("Segoe UI Semibold", 11, "bold"), spacing1=8, spacing3=5)
        text.configure(state="disabled")

    def _set_status(self, text: str):
        self.status_var.set(text)

    def start_scan(self):
        if self.scan_thread and self.scan_thread.is_alive():
            return
        if not self.consent_var.get():
            messagebox.showwarning("Подтвердите разрешение", "Отметьте подтверждение, что вы владелец системы или имеете явное разрешение на проверку.")
            return
        try:
            target = normalize_target(self.target_var.get())
        except ScopeError as exc:
            messagebox.showerror("Некорректная цель", str(exc))
            return
        modules = [name for name, var in self.module_vars.items() if var.get()]
        if not modules:
            messagebox.showwarning("Нет модулей", "Выберите хотя бы один модуль проверки.")
            return
        confirm = messagebox.askyesno(
            "Подтвердите запуск",
            f"Цель: {target}\n\nПроверка будет ограничена одним доменом/IP. TCP-модуль проверяет только 38 часто используемых портов.\n\nЗапустить проверку?",
        )
        if not confirm:
            return
        consent_path = self.data_dir / "authorization-log.txt"
        with consent_path.open("a", encoding="utf-8") as stream:
            stream.write(f"{datetime.utcnow().isoformat()}Z | user-confirmed | {target}\n")
        self._clear_results()
        self.current_result = None
        self.progress.start(12)
        self._set_status(f"Запуск проверки {target}…")
        self.scan_thread = threading.Thread(target=self._scan_worker, args=(target, modules), daemon=True)
        self.scan_thread.start()

    def _scan_worker(self, target: str, modules: list[str]):
        try:
            result = run_assessment(target, modules, progress=lambda message: self.events.put(("progress", message)))
            scan_id = self.store.save(result)
            self.events.put(("complete", result, scan_id))
        except Exception as exc:
            self.events.put(("error", f"{type(exc).__name__}: {exc}"))

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "progress":
                    self._set_status(event[1])
                elif event[0] == "complete":
                    _, result, scan_id = event
                    self.current_result = result
                    self.progress.stop()
                    self._populate_results(result)
                    self._refresh_history()
                    self._set_status(f"Готово: {result['target']} · найдено наблюдений: {len(result.get('findings', []))} · запись #{scan_id}")
                elif event[0] == "error":
                    self.progress.stop()
                    self._set_status("Проверка завершилась с ошибкой.")
                    messagebox.showerror("Ошибка проверки", event[1])
        except queue.Empty:
            pass
        self.root.after(150, self._poll_events)

    def _clear_results(self):
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)
        self.finding_lookup.clear()
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        self.detail_text.insert("1.0", "Проверка выполняется…")
        self.detail_text.configure(state="disabled")

    def _populate_results(self, result: dict):
        self._clear_results()
        for index, finding in enumerate(result.get("findings", [])):
            item_id = str(index)
            self.finding_lookup[item_id] = finding
            self.results_tree.insert("", "end", iid=item_id, values=(finding.get("severity", "INFO"), finding.get("category", ""), finding.get("title", "")))
        if not result.get("findings"):
            self.results_tree.insert("", "end", values=("INFO", "Assessment", "Для выбранных модулей замечаний не обнаружено."))
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        self.detail_text.insert("1.0", "Выберите наблюдение, чтобы посмотреть детали и рекомендации.")
        self.detail_text.configure(state="disabled")

    def _show_finding_details(self, _event=None):
        selection = self.results_tree.selection()
        if not selection:
            return
        finding = self.finding_lookup.get(selection[0])
        if not finding:
            return
        text = (
            f"{finding.get('title', '')}\n"
            f"Уровень: {finding.get('severity', 'INFO')}    Модуль: {finding.get('category', '')}\n\n"
            f"Доказательства / детали:\n{finding.get('details', '')}\n\n"
            f"Рекомендация:\n{finding.get('recommendation', '')}"
        )
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        self.detail_text.insert("1.0", text)
        self.detail_text.configure(state="disabled")

    def export_html(self):
        if not self.current_result:
            messagebox.showinfo("Нет данных", "Сначала выполните проверку.")
            return
        filename = f"panzer-{self.current_result['target'].replace(':', '-')}-{datetime.now():%Y%m%d-%H%M%S}.html"
        path = filedialog.asksaveasfilename(defaultextension=".html", initialfile=filename, filetypes=[("HTML report", "*.html")])
        if path:
            save_html(self.current_result, Path(path))
            messagebox.showinfo("Отчёт сохранён", f"HTML-отчёт сохранён:\n{path}")

    def export_json(self):
        if not self.current_result:
            messagebox.showinfo("Нет данных", "Сначала выполните проверку.")
            return
        filename = f"panzer-{self.current_result['target'].replace(':', '-')}-{datetime.now():%Y%m%d-%H%M%S}.json"
        path = filedialog.asksaveasfilename(defaultextension=".json", initialfile=filename, filetypes=[("JSON report", "*.json")])
        if path:
            save_json(self.current_result, Path(path))
            messagebox.showinfo("Экспорт завершён", f"JSON сохранён:\n{path}")

    def _refresh_history(self):
        if not hasattr(self, "history_tree"):
            return
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        for row in self.store.recent(200):
            self.history_tree.insert("", "end", values=(row["id"], row["target"], row["started_at"], row["findings_count"]))

    def _open_history_item(self, _event=None):
        selection = self.history_tree.selection()
        if not selection:
            return
        values = self.history_tree.item(selection[0], "values")
        result = self.store.get(int(values[0]))
        if result:
            self.current_result = result
            self._populate_results(result)
            self.notebook.select(self.scan_tab)
            self._set_status(f"Открыта локальная запись #{values[0]}: {values[1]}")


def main():
    root = tk.Tk()
    PanzerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
