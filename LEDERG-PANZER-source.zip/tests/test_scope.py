import unittest

from panzer.scope import ScopeError, normalize_target


class NormalizeTargetTests(unittest.TestCase):
    def test_accepts_domain_and_normalizes_case(self):
        self.assertEqual(normalize_target(' Example.COM '), 'example.com')

    def test_accepts_ipv4(self):
        self.assertEqual(normalize_target('192.0.2.10'), '192.0.2.10')

    def test_accepts_ipv6(self):
        self.assertEqual(normalize_target('2001:db8::1'), '2001:db8::1')

    def test_rejects_url_path_and_scheme(self):
        with self.assertRaises(ScopeError):
            normalize_target('https://example.com/login')

    def test_rejects_cidr_and_wildcards(self):
        for target in ('192.0.2.0/24', '*.example.com', 'example.com:443'):
            with self.subTest(target=target):
                with self.assertRaises(ScopeError):
                    normalize_target(target)

    def test_rejects_empty_or_invalid_domain(self):
        for target in ('', 'not a domain', '-bad.example'):
            with self.subTest(target=target):
                with self.assertRaises(ScopeError):
                    normalize_target(target)


if __name__ == '__main__':
    unittest.main()
