import unittest

from panzer.report import render_html


class ReportTests(unittest.TestCase):
    def test_escapes_untrusted_target_and_finding_text(self):
        report = render_html({
            'target': '<script>alert(1)</script>',
            'findings': [{
                'severity': 'HIGH', 'title': '<img src=x>', 'details': 'x < y',
                'recommendation': '& fix', 'category': 'test'
            }],
        })
        self.assertNotIn('<script>', report)
        self.assertIn('&lt;script&gt;', report)
        self.assertIn('&lt;img src=x&gt;', report)
        self.assertIn('x &lt; y', report)

    def test_report_includes_empty_state(self):
        report = render_html({'target': 'example.com', 'findings': []})
        self.assertIn('Замечаний не обнаружено', report)


if __name__ == '__main__':
    unittest.main()
